#define CONFIG_MAN 1
