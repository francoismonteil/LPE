#define CONFIG_SHUF 1
